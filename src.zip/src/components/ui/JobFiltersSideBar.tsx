import { useMemo } from "react";

/**
 * Single source of truth type should ideally come from:
 * useJobSearchController.ts
 */
export type Job = {
  id: number;
  title: string;
  location: string;
  department: string;
  description: string;
  status: string;
  postedAt: string;
};

export type JobFilters = {
  search: string;
  locations: string[];
  departments: string[];
};

type Props = {
  jobs: Job[] | undefined;

  filters: JobFilters;

  setSearch: (v: string) => void;
  toggleLocation: (v: string) => void;
  toggleDepartment: (v: string) => void;
  reset: () => void;
};

function Chip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-3 py-1 rounded-full text-sm border transition
        ${
          active
            ? "bg-blue-600 text-white border-blue-600"
            : "bg-white text-slate-600 border-slate-200"
        }`}
    >
      {label}
    </button>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium text-slate-700">{title}</h3>
      {children}
    </div>
  );
}

export function JobFiltersSideBar({
  jobs,
  filters,
  toggleLocation,
  toggleDepartment,
  reset,
}: Props) {
  // SAFE + memoised derived filters (prevents recompute every render)
  const locations = useMemo(() => {
    if (!jobs?.length) return [];
    return Array.from(new Set(jobs.map((j) => j.location))).sort();
  }, [jobs]);

  const departments = useMemo(() => {
    if (!jobs?.length) return [];
    return Array.from(new Set(jobs.map((j) => j.department))).sort();
  }, [jobs]);

  return (
    <aside className="w-full max-w-sm bg-white rounded-2xl shadow-md border border-slate-100 p-4 space-y-5">
      {/* LOCATIONS */}
      <Section title="Locations">
        <div className="flex flex-wrap gap-2">
          {locations.map((loc) => (
            <Chip
              key={loc}
              label={loc}
              active={filters.locations.includes(loc)}
              onClick={() => toggleLocation(loc)}
            />
          ))}
        </div>
      </Section>

      {/* DEPARTMENTS */}
      <Section title="Departments">
        <div className="flex flex-wrap gap-2">
          {departments.map((dep) => (
            <Chip
              key={dep}
              label={dep}
              active={filters.departments.includes(dep)}
              onClick={() => toggleDepartment(dep)}
            />
          ))}
        </div>
      </Section>

      {/* RESET */}
      <button
        onClick={reset}
        className="w-full text-sm text-slate-500 hover:text-slate-800"
      >
        Reset filters
      </button>
    </aside>
  );
}
