import JobFilters from "../ui/JobFiltersSideBar";
import JobSort from "../ui/JobSort";

type Filters = {
  department: string;
  location: string;
  sort: "newest" | "relevance";
};

type Props = {
  children: React.ReactNode;
  filters: Filters;
  setFilters: <K extends keyof Filters>(key: K, value: Filters[K]) => void;
};

export default function JobsLayout({ children, filters, setFilters }: Props) {
  return (
    <div className="grid grid-cols-4 gap-6">
      {/* SIDEBAR */}
      <aside className="col-span-1">
        <JobFilters
          department={filters.department}
          location={filters.location}
          setDepartment={(v) => setFilters("department", v)}
          setLocation={(v) => setFilters("location", v)}
        />
      </aside>

      {/* MAIN */}
      <main className="col-span-3 space-y-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Job Listings</h2>

          <div className="flex items-center gap-3">
            <JobSort
              sort={filters.sort}
              setSort={(v) => setFilters("sort", v)}
            />
          </div>
        </div>
        {children}
      </main>
    </div>
  );
}
